
<input type="hidden" name="name" value="takemoto">
<input type="hidden" name="name_romazi" value="test">
<input type="hidden" name="email" value="test@test.com">
<input type="hidden" name="category" value="category">
<input type="hidden" name="message" value="testtesttest">
