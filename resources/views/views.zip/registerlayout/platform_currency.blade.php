<div class="row mb-10">
    <div class="col-md-2">
        <div class="text_right_box3">
            口座通貨
        </div>
    </div>
    <div class="col-md-10">
        <input class="form-control form-md" type="text" name="basic_information[currency]" />
    </div>
</div>

<div class="row mb-10">
    <div class="col-md-2 ">
        <div class="text_right_box3">
            レバレッジ
        </div>
    </div>
    <div class="col-md-10">
        <select class="form-control form-md" name="basic_information[leverage]">
            <option value="">選択して下さい</option>
        </select>
    </div>
</div>