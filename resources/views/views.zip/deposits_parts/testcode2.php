
<input type="hidden" name="name" value="test">
<input type="hidden" name="email" value="test@test.com">
<input type="hidden" name="howmuch" value="100,000">
<input type="hidden" name="account_number" value="2096561335">
<input type="hidden" name="phone" value="0802228112">
<input type="hidden" name="howdo" value="bank">
<input type="hidden" name="receiver_name" value="testmeigi">
<input type="hidden" name="receiver_address" value="test12@test.com">
<input type="hidden" name="receiver_accountnum" value="0000111">
<input type="hidden" name="receiver_bankname" value="risona">
<input type="hidden" name="receiver_bankbranch" value="Kyoto">
<input type="hidden" name="receiver_bankkind" value="Ordinary">
<input type="hidden" name="receiver_bankaddress" value="Kyotoshi">
<input type="hidden" name="receiver_swift" value="aaaaaa">
<input type="hidden" name="receiver_bikou" value="特になし">
