<!DOCTYPE html>
<!-- saved from url=(0058)https://www.good-enoughlatam.com/ja/forms/additional-account -->
<html lang="ja">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


	</script>
	<script async="" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/js"></script>


	<meta http-equiv="content-language" content="ja">
	<title>good-enough アフィリエイトパートナー登録申請</title>


	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="shortcut icon" type="image/x-icon" href="https://www.good-enoughlatam.com/ja/assets/img/favicon.ico">
	<link rel="stylesheet" href="{{asset('css/app.min.css')}}">



	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/jquery.min.js"></script>
	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/popper.min.js"></script>
	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/bootstrap.min.js"></script>
	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/bootstrap-select.min.js"></script>
	<link rel="stylesheet" href="{{asset('css/basic.css')}}">

	<script src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/api.js"></script>
	<script>
		/* Function to show in Unities an int of Bytes */
		function formatBytes(a, b) {
			if (0 == a) return "0 Bytes";
			var c = 1024,
				d = b || 2,
				e = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
				f = Math.floor(Math.log(a) / Math.log(c));
			return parseFloat((a / Math.pow(c, f)).toFixed(d)) + " " + e[f]
		}
	</script>
	<!-- TrustBox script -->
	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/tp.widget.bootstrap.min.js" async=""></script> <!-- End TrustBox script -->
</head>

<body>
	<div class="main-wrap">

		<style type="text/css">
			.op_menu,
			.clo_menu,
			.control-menu {
				display: none;
			}

			@media (max-width: 995px) {

				.siteTopSection {
					background: white;
				}

				.control-menu {
					display: block;
					position: relative;
					float: right;
					top: 20%;
					font-size: xx-large;

				}

				.jk {
					top: 300%;
					position: fixed;
					margin: 0;
					padding: 0;
					left: 0;
					visibility: block;

				}

				.siteTopSection ul {
					margin: 0;
					padding: 0;
					left: 0;
					flex-direction: row;
					position: fixed;

				}
			}
		</style>


		@include('layouts.header')

		@include('layouts.inquery_form')

		@include('layouts.inquery_responce')

		@include('layouts.header2')


		<style type="text/css">
			.modal.custom .modal-dialog {
				width: 350px;
				position: fixed;
				right: 0;
				top: 0;
				margin: 0;
			}

			@media (max-width: 400px) {
				.modal.custom .modal-dialog {
					width: 70%;
					position: fixed;
					top: 0;
					right: 10px;
					margin: 0;
				}
			}



			.bg_image {
				width: 1280px;
				margin-left: -640px;
				position: relative;
				left: 50%;
			}

			@media screen and (min-width: 1281px) {
				.register_btn {
					width: 311px;
					margin-left: -795.5px;
					margin-top: 200px;
					position: relative;
					left: 50%;
				}

				.parent1 {
					position: relative;
					width: 100%;
					max-width: 1280px;
					position: relative;
					left: 50%;
					margin-left: -640px;
				}

				.parent2 {
					position: relative;
					width: 100%;
					max-width: 1280px;
					position: relative;
					left: 50%;
					margin-left: -640px;
				}

				.parent3 {
					position: relative;
					width: 100%;
					max-width: 1280px;
					position: relative;
					left: 50%;
					margin-left: -640px;
				}

				.parent4 {
					position: relative;
					width: 100%;
					max-width: 1280px;
					position: relative;
					left: 50%;
					margin-left: -640px;
				}

				.parent5 {
					position: relative;
					width: 100%;
					max-width: 1280px;
					position: relative;
					left: 50%;
					margin-left: -640px;
				}

				.parent6 {
					position: relative;
					width: 100%;
					max-width: 1280px;
					position: relative;
					left: 50%;
					margin-left: -640px;
				}

				.inner1 {
					display: table-cell;
					vertical-align: middle;
					font-size: 43px;
				}

				.parent6:before {
					content: "";
					display: block;
					padding-top: 35%;
				}
			}

			@media screen and (max-width: 1280px) {
				.parent6:before {
					content: "";
					display: block;
					padding-top: 110%;
				}

				.wrapper {
					width: 100%;
					overflow: hidden;
				}

				.lp_main {
					width: 150%;
					margin-left: -25%;
				}

				.parent1 {
					position: relative;
					width: 100%;
					max-width: 1280px;
				}

				.parent2 {
					position: relative;
					width: 100%;
					max-width: 1280px;
				}

				.parent3 {
					position: relative;
					width: 100%;
					max-width: 1280px;
				}

				.parent4 {
					position: relative;
					width: 100%;
					max-width: 1280px;
				}

				.parent5 {
					position: relative;
					width: 100%;
					max-width: 1280px;
				}

				.parent6 {
					position: relative;
					width: 100%;
					max-width: 1280px;
				}

				.bg_image {
					width: 100%;
					margin-left: -50%;
				}

				.register_btn {
					width: 21.5%;
					margin-left: -60.75%;
					margin-top: 15%;
					position: relative;
					left: 50%;
				}

				.inner1 {
					display: table-cell;
					vertical-align: middle;
					font-size: 3vw;
				}
			}

			body {
				width: 100%;
				overflow-x: hidden;
			}


			.parent1:before {
				content: "";
				display: block;
				padding-top: 37.6%;
			}

			.parent2:before {
				content: "";
				display: block;
				padding-top: 23.6%;
			}

			.parent3:before {
				content: "";
				display: block;
				padding-top: 27.6%;
			}

			.parent4:before {
				content: "";
				display: block;
				padding-top: 27.3%;
			}

			.parent5:before {
				content: "";
				display: block;
				padding-top: 24.0%;
			}

			.child {
				position: absolute;
				top: 0;
				left: 0;
				bottom: 0;
				right: 0;
			}

			.text_p1 {
				position: absolute;
				top: 0;
				right: 0;
				bottom: 0;
				left: 0;
				margin: auto;
				width: 100%;
				text-align: center;
				height: 100%;
				display: table;
			}

			.dokuziform {
				float: left;
				max-width: 300px;
				width: 100%;
				text-align: left;
				margin-top: 20px;
			}

			.dokuziform2 {
				float: left;
				max-width: 600px;
				width: 100%;
				text-align: left;
				margin-top: 20px;
			}

			.submitbtn {
				margin-top: 20px;
			}

			.dokuziform>input {
				width: 100%;
				border-top-width: 0px;
				border-left-width: 0px;
				border-right-width: 0px;
			}

			.dokuziform2>input {
				width: 100%;
				border-top-width: 0px;
				border-left-width: 0px;
				border-right-width: 0px;
			}

			.dokuziinner {
				width: 80%;
				margin: 0 auto;
			}
		</style>

		<style>
			input.form-control {
				position: absolute;
				top: 18px !important;
			}

			label.control-label {
				position: absolute;
				top: 0px !important;
			}
		</style>

		<div class="wrapper">
			<div class="lp_main">

				<div class="parent1">
					<div class="child">
						<img class="bg_image" alt="ロゴ" src="{{ asset('/img/affiliate-lp1/h_01.jpg') }}">
					</div>
				</div>

				<div class="parent2">
					<div class="child">
						<img class="bg_image" alt="ロゴ" src="{{ asset('/img/affiliate-lp1/h_02.jpg') }}">
					</div>
				</div>

				<div class="parent3">
					<div class="child">
						<img class="bg_image" alt="ロゴ" src="{{ asset('/img/affiliate-lp1/h_03.jpg') }}">
					</div>
				</div>

				<div class="parent4">
					<div class="child">
						<img class="bg_image" alt="ロゴ" src="{{ asset('/img/affiliate-lp1/h_04.jpg') }}">
					</div>
				</div>

				<div class="parent5">
					<div class="child">
						<img class="bg_image" alt="ロゴ" src="{{ asset('/img/affiliate-lp1/h_05.jpg') }}">
					</div>
				</div>

				<div class="parent6" style="background-color:#A14A36;">
					<div class="child">
						<center>
							<form style="width:60%;background-color:white;border-radius:30px;" method="post" action="{{route('affiliatethanks')}}">
								@csrf
								<div class="dokuziinner">

									<div class="dokuziform">
										*登録名<br>
										<input type="text" name="name" value="{{$login_user->name}}" readonly="readonly" 　 />
									</div>
									<div class="dokuziform">
										*メールアドレス<br>
										<input type="text" name="email" value="{{$login_user->email}}" readonly="readonly" 　 />
									</div>
									<div class="dokuziform">
										*口座番号<br>
										<input type="text" name="account" value="{{$login_user->account_number}}" readonly="readonly" 　 />
									</div>
									<div class="dokuziform">
										*レバレッジ<br>
										<input type="text" name="revelege" value="100" readonly="readonly" 　 />
									</div>
									<div class="dokuziform">
										*通貨<br>
										<input type="text" name="currency" value="USD" readonly="readonly" />
									</div>
									<div class="dokuziform">
										*取引プラットフォーム<br>
										<input type="text" name="platform" value="アフィリエイト口座" readonly="readonly" />
									</div>
									<div class="dokuziform2">
										連絡事項<br>
										<input type="text" name="contact" />
									</div>

									<input type="image" src="{{ asset('/img/affiliate-lp1/btn.png') }}" class="submitbtn" />
								</div>
							</form>
						</center>
					</div>
				</div>

			</div>
		</div>



		<link rel="stylesheet" href="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/materialize-style-form.css">
		<link rel="stylesheet" href="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/signature-pad.css">
		<link rel="stylesheet" href="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/style-attorney.css">




		<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/custom-file-input.js"></script>
		<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/additional-account.js"></script>





		@include('layouts.footer')



		<!-- Icons -->
		<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/feather.min.js"></script>
		<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/app.js"></script>
		<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/jquery-migrate-1.2.1.min.js"></script>





		<iframe style="display: none;" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/saved_resource.html"></iframe>
	</div>
	<style>
		.tb_button {
			padding: 1px;
			cursor: pointer;
			border-right: 1px solid #8b8b8b;
			border-left: 1px solid #FFF;
			border-bottom: 1px solid #fff;
		}

		.tb_button.hover {
			borer: 2px outset #def;
			background-color: #f8f8f8 !important;
		}

		.ws_toolbar {
			z-index: 100000
		}

		.ws_toolbar .ws_tb_btn {
			cursor: pointer;
			border: 1px solid #555;
			padding: 3px
		}

		.tb_highlight {
			background-color: yellow
		}

		.tb_hide {
			visibility: hidden
		}

		.ws_toolbar img {
			padding: 2px;
			margin: 0px
		}
	</style>

	</div>

</body>

</html>