<!DOCTYPE html>
<!-- saved from url=(0058)https://www.good-enoughlatam.com/ja/forms/additional-account -->
<html lang="ja"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	

    </script><script async="" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/js"></script>
     
     
	<meta http-equiv="content-language" content="ja">
	<title>good-enough スペシャルアフィリエイトパートナー登録申請</title>
		

	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<link rel="shortcut icon" type="image/x-icon" href="https://www.good-enoughlatam.com/ja/assets/img/favicon.ico">
	<link rel="stylesheet" href="{{asset('css/app.min.css')}}">

	<link rel="stylesheet" href="{{asset('css/basic.css')}}">
	
<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/jquery.min.js"></script>
<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/popper.min.js"></script>
<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/bootstrap.min.js"></script>
<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/bootstrap-select.min.js"></script>

<script src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/api.js"></script>
<script>
	/* Function to show in Unities an int of Bytes */
	function formatBytes(a,b){if(0==a)return"0 Bytes";var c=1024,d=b||2,e=["Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"],f=Math.floor(Math.log(a)/Math.log(c));return parseFloat((a/Math.pow(c,f)).toFixed(d))+" "+e[f]}


	
	</script>
	<!-- TrustBox script --> <script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/tp.widget.bootstrap.min.js" async=""></script> <!-- End TrustBox script -->
		</head>
<body>


<div class="main-wrap">
	
		<!--  -->
		
<!-- <nav class="navbar navbar-expand-lg navbar-light bg-dark sticky-top">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
	<span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#">Navbar</a>
  <div class="collapse navbar-collapse container-fluid p-0" id="mainNavbar">
	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	  <li class="nav-item active">
		<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
	  </li>
	  <li class="nav-item">
		<a class="nav-link" href="#">Link</a>
	  </li>
	  <li class="nav-item">
		<a class="nav-link disabled" href="#">Disabled</a>
	  </li>
	</ul>
	<form class="form-inline my-2 my-lg-0">
	  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
	  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
	</form>
  </div>
</nav> -->

<style type="text/css">

	.text-primary{
		color:red!important;
	}
   
   .op_menu, .clo_menu, .control-menu{
   	display:none;
   }

  	@media (max-width: 995px){

  		.siteTopSection{
  			background: white;
  		}

  		.control-menu{
  			display: block;
  			position: relative;
  			float: right;
  		    top: 20%;
  		    font-size: xx-large;

  		}

        .jk{
        	top: 300%;
        	position: fixed;
        	margin: 0;
        	padding: 0;
        	left: 0;
        	visibility: block;

        }
  		.siteTopSection ul{		
  			margin: 0;
        	padding: 0;
        	left:0;
  			flex-direction: row;
  			position: fixed;		

  		}
  </style>

  <style>
input.form-control
{
    position:absolute;
    top:18px!important;
}

label.control-label
{
    position:absolute;
    top:0px!important;
}
</style>


  
@include('layouts.header')

@include('layouts.inquery_form')

@include('layouts.inquery_responce')

@include('layouts.header2')


<style type="text/css">
	
.modal.custom .modal-dialog {
    width:350px;
    position:fixed;
    right: 0;
    top: 0;
    margin:0;
 }

@media (max-width: 400px){
  .modal.custom .modal-dialog {
    width:70%;
    position:fixed;
    top: 0;
    right:10px;
    margin:0;
 }
}
</style>


<div class="modal custom fade" id="sidebar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">       
      <div class="modal-body">
      	 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color: black; font-size: xx-large;">×</span>
         </button><br><br>
				
								 
								 
							  
					<a class="btn btn-default h-100 center-with-flex" href="https://www.good-enough.com/ja/accounts/funding?ref=latam" target="_blank">入出金</a>
			
		
            </div>
         </div>
       </div>
    </div>

			<link rel="stylesheet" href="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/materialize-style-form.css">
<link rel="stylesheet" href="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/signature-pad.css"> 
<link rel="stylesheet" href="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/style-attorney.css">

<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="row">
				<div class="container">
					<div class="row introductionTeam">
						<div class="col-md-12 pt-3">
							<br><h1 class="text-center">good-enough スペシャルアフィリエイトパートナー登録申請</h1>
						</div>
						<div class="col-md-12 pt-3">
							<br><h3 class="text-center">アフィリエイトを申し込み頂き、誠にありがとうございます。<br>下記の情報の記載をお願い致します。</h3>
						</div>
						<div class="col-md-12 pt-3">
							<br><h2>パートナー申請情報</h2>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="container">
					<div class="row pt-3">
						<form id="additionalAccount" method="POST" enctype="multipart/form-data" class="col-md-12 materializeForm" action="{{route('affiliatethanks2')}}" autocomplete="off">
							@csrf
							<div class="row pt-4 pb-4">
								<div class="col-sm-12"> 
									<div class="row fieldContainer">
										<div class="col-md-6 spaceFields">
											<fieldset class="input">
												<input name="basic_information[name]" type="text" data-custom-user-form="name" class="form-control" placeholder="半角英字（yamadataro）" value="" required>
												<label  for="basic_information[name]"><span class="text-primary">*</span>登録名：</label>             
											</fieldset>
										</div>
										<div class="col-md-6 spaceFields">
											<fieldset class="input">
												<input type="email" name="basic_information[email]" class="form-control" data-custom-user-form="email" placeholder="半角英数字（taro@gmail.com）" value="" required>
												<label  for="basic_information[email]"><span class="text-primary">*</span>メールアドレス：</label>                   
											</fieldset>
										</div>
									</div>
								</div>
							</div>
							<br>
							<div class="row mt-4">
							
							
							
								<div class="col-sm-12"> 
									<div class="row fieldContainer">
										<div class="col-md-6 spaceFields">
											<fieldset class="input">
												<input name="basic_information[code]]" type="text" data-custom-user-form="name" class="form-control" placeholder="半角数字（000000）" value="{{$ref_name}}">
												<label  for="basic_information[code]">登録コード：</label>             
											</fieldset>
										</div>
									</div>
								</div>
							
							</div>
							<br>
							<div class="row">
								<div class="col-md-12 center-with-flex">
									<button type="submit" class="btn btn-lg btn-primary mx-auto w-50 d-block">申し込む</button>
									<div class="loader" style="display:none"></div>
								</div>
							</div>
							<input type="hidden" name="backend[form_link]" value="https://www.good-enoughlatam.com/ja/ja/forms/additional-account">
							<input type="hidden" name="backend[user][email]">
							<input type="hidden" name="backend[user][name]">
							<input type="hidden" name="backend[page]" value="">
							<input type="hidden" name="gCaptchaAction" value="">
						</form>
					</div>					
				</div>
			</div>
		</div>		
	</div>	
</div>

<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/custom-file-input.js"></script>
<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/additional-account.js"></script>




	
@include('layouts.footer')

	

	<!-- Icons -->
	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/feather.min.js"></script>
	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/app.js"></script>
	<script type="text/javascript" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/jquery-migrate-1.2.1.min.js"></script>
	


<div>

<iframe style="display: none;" src="{{$currentPath}}/good-enough 追加口座申請｜good-enough _ good-enough_files/saved_resource.html"></iframe></div><style>.tb_button {padding:1px;cursor:pointer;border-right: 1px solid #8b8b8b;border-left: 1px solid #FFF;border-bottom: 1px solid #fff;}.tb_button.hover {borer:2px outset #def; background-color: #f8f8f8 !important;}.ws_toolbar {z-index:100000} .ws_toolbar .ws_tb_btn {cursor:pointer;border:1px solid #555;padding:3px}   .tb_highlight{background-color:yellow} .tb_hide {visibility:hidden} .ws_toolbar img {padding:2px;margin:0px}</style>

</div>

</body></html>