<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="utf-8">
	<title>
		GOOD ENOUGH FX
	</title>
</head>

<body>

	<div class="main-wrap">
		@include('layouts.header')
	
	デモ口座申請完了

		@include('layouts.footer')
	</div>

</body>
</html>