<!DOCTYPE html>
<!-- saved from url=(0101)https://www.good-enoughlatam.com/ja/forms/accounts/individual?processform=agreement&formtype=individual -->
<html lang="ja"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
	
   	
	<meta http-equiv="content-language" content="ja">
	<title>good-enough 個人口座申請 | good-enough</title>
		<!-- 全体 -->
	<link rel="stylesheet" href="{{asset('css/basic.css')}}">

	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<link rel="shortcut icon" type="image/x-icon" href="https://www.good-enoughlatam.com/ja/assets/img/favicon.ico">
	<link rel="stylesheet" type="text/css" href="{{$currentPath}}/good-enough 個人口座申請 _ good-enough_files/slick.css">
	<link rel="stylesheet" type="text/css" href="{{$currentPath}}/good-enough 個人口座申請 _ good-enough_files/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="{{$currentPath}}/good-enough 個人口座申請 _ good-enough_files/app.css">
	<link rel="stylesheet" type="text/css" href="{{$currentPath}}/good-enough 個人口座申請 _ good-enough_files/custom.css">



	
	
</head>
<body>
	
	

		
			<style>
	.title-OpenAcount{background:url(/assets/img/backgrounds/bg-open-account.jpg);background-size: cover; background-position: center bottom; background-repeat: no-repeat;}
	.title-OpenAcount .blackBG {background: rgba(0, 0, 0, 0.70); box-shadow: 0 0 40px -10px rgba(0,0,0,1); }
	.title-OpenAcount blockquote {border: 0; margin: 0; min-height: 200px; overflow: hidden; position: relative; }
	.title-OpenAcount blockquote .contentQuote {left: 0; padding: 30px; position: absolute; top: 50%; -webkit-transform: translateY(-50%); -ms-transform: translateY(-50%); transform: translateY(-50%); width: 100%; }
	.title-OpenAcount blockquote .contentQuote p {font-size: 20px; font-weight: 300; line-height: 25px; padding-top: 20px; position: relative; text-align: center; z-index: 2; }

	.box-2{border: 1px solid #e4e3e3; padding: 40px 20px 20px!important; margin-bottom: 40px; border-radius: 2px;}
</style>

<div class="container-fluid">
			<section class="row title-OpenAcount" style="background-image: url('{{$currentPath}}/img/obi.png')">
			<div class="container">
				<div class="row">
					<div class="col-sm-8"></div>
					<div class="col-sm-4 blackBG">
						<blockquote>
							<div class="contentQuote">
																	<p class="text-white"></p>
															</div>
						</blockquote>
					</div>
				</div>
			</div>
		</section>
	
	<section class="row">
		<div class="container">
			<div class="row justify-content-center introductionTeam">
				<div class="col-md-10">
					<br>
											<h1 class="text-center">ご入力のメールアドレスはすでに登録されています。<br>
大変申し訳ございませんが、他のメールアドレスをお試しください</h1>
									</div>

				<div class="col-md-4 box-2">

																		<p class="text-center"></p>
						
													<p><a href="{{route('top')}}" class="btn btn-danger d-block">ホームに戻る <i class="fa fa-chevron-right" aria-hidden="true"></i></a></p>
						
					
				</div>
			</div>
		</div>
	</section>
</div>	
	


	
	</body></html>