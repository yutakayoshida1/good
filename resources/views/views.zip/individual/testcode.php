
<input type="hidden" name="first_name" value="test">
<input type="hidden" name="last_name" value="test">
<input type="hidden" name="email" value="test@test.com">