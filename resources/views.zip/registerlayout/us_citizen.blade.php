米国市民権に関する情報<br>
該当するものにチェックを入れてください<br>


* 米国市民権・永住権に関して:<br>

<input type="radio" name="hyouka" value="bad">(a) 米国市民権・永住権を保持しています (green card holder/ resident under the substantial presence test)<br>
<input type="radio" name="hyouka" value="bad">(b) 出生は米国ですが市民権を放棄したため現在は米国籍ではありません ( 証明書の添付が必要となります)<br>
<input type="radio" name="hyouka" value="bad">(c) 米国市民権や永住権はありません<br>