<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="utf-8">
	<title>
		GOOD ENOUGH FX
	</title>
	<link rel="stylesheet" href="{{asset('css/basic.css')}}">
</head>

<body>

<div class="main-wrap">
@include('layouts.header')	

問い合わせ完了

@include('layouts.footer')
</div>

</body>
</html>