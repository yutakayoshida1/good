<div style="text-align:center;">
    <h1>銀行送金</h1><br>
    <h2>下記口座にお振り込みをお願いいたします</h2><br>
    反映までの時間: 最大３営業日　　振り込み手数料: お客様負担でお願いいたします。<br>
    <br>
    三菱UFJ 銀行　福岡支店　普通口座　口座番号9999999 口座名義　カ）グツドイナフエフエツクス<br>
    <br>
    <div class="box_shadow" style="background-color:red;color:white;border-color:white;border: 2px solid;padding:3px;">
        <h3>振り込みに際してのご注意点</h3>
    </div>
    <br><br>
</div>

<div style="text-align:left;color:red;">
    ★必ず振り込み名には登録口座のお名前とMT４口座番号をご入力下さいますよう<br>
    　お願い申し上げます。<br>
    <br>
    ★MT４口座番号が入力されておりませんと残高に反映できない場合がございますので<br>
    　ご注意下さい。<br>
    <br>
    <br>
</div>

<div style="text-align:left;">
◇金融商品取引は高リスクを伴う為、損失に耐えうる資金投資をして下さい<br>
◇場合により口座への入金反映が通常より遅れる場合がございます<br>
◇当社が取扱わない通貨、トークン等を誤ってお預入された場合、原則として返還対応いたしかねます。返還が可能な場合においても、<br>
　それに係る手数料等をお支払いただくことがあります。<br>
◇ご入金には手数料（2.5%）が発生致します。<br>
◇外国為替相場については、三菱UFJ銀行（TTS AM11:00）のレートを適応しております。<br>
</div>