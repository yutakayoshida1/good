<!DOCTYPE html>
<html lang="ja" class="home  ">

<head>
	<meta charset="utf-8">
	<title>
		good enough|オンラインFXトレード
	</title>
	
	<link name="canonical" href="index.html">


	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" type="image/x-icon" href="{{$currentPath}}/../assets/img/tn-favicon.ico.png">


	<link rel="stylesheet" href="{{asset('css/basic.css')}}">
	<link rel="stylesheet" href="{{$currentPath}}/../assets/css/app.min-v=0.01.25.css">
	<link rel="stylesheet" href="{{$currentPath}}/../assets/css/custom-d-v=0.01.25.css">
	<link rel="stylesheet" href="{{$currentPath}}/../assets/css/custom-j-v=0.01.25.css">



	<meta name="description" content="グッドイナフ【good enough】は仮想通貨入出金,MT4対応,FXトレードで業界最狭のスプレッドを誇るネット証券会社です。世界のトレーダーにMT4口座等をご提供しています。">

	<style>

		

		.bg_image{
			width:1280px;
			margin-left:-640px;
			position:relative;
			left:50%;
		}
		.bg_text{
			position:absolute;
			
			width:1280px;
			text-align:center;
		}

		.bg_text1{
			top:170px;
			font-size:40px;
			color:white;
		}
		
	    .bg_text1_1{
			top:00px;
			font-size:40px;
			color:#7E4D3D;
		}

		.bg_text2_1{
			top:60px;
			font-size:28px;
			color:#7E4D3D;
		}

		.bg_text2_2{
			top:110px;
			font-size:28px;
			color:#7E4D3D;
		}

		.bg_text3_1{
			top:130px;
			left:100px;
			font-size:30px;
			color:black;
			text-align:left;
			width:800px;
		}

		.bg_text3_2{
			top:780px;
			left:420px;
			font-size:35px;
			color:black;
			font-weight:bold;
			width:800px;
		}

		/* 見出し下の説明文*/
		.bg_text4_1{
			top:170px;
			font-size:40px;
			color:white;
		}

		.bg_text4_2_2{
			top:185px;
			left:700px;
			width:500px;
			font-size:20px;
			color:black;
			text-align:left;
		}

		.bg_text4_3_2{
			top:375px;
			left:700px;
			width:500px;
			font-size:20px;
			color:black;
			text-align:left;
		}

		.bg_text4_4_2{
			top:565px;
			left:700px;
			width:500px;
			font-size:20px;
			color:black;
			text-align:left;
		}

		/* 見出し */
		.bg_text4_2_1{
			top:110px;
			left:420px;
			font-size:35px;
			color:black;
			font-weight:bold;
			width:800px;
		}

		.bg_text4_3_1{
			top:310px;
			left:420px;
			font-size:35px;
			color:black;
			font-weight:bold;
			width:800px;
		}

		.bg_text4_4_1{
			top:490px;
			left:420px;
			font-size:35px;
			color:black;
			font-weight:bold;
			width:800px;
		}

		.bg_text4_5{
			top:900px;
			font-size:30px;
			font-weight:bold;
		}

		.bg_text4_6_1{
			top:335px;
			left:80px;
			font-size:30px;
			text-align:left;
			width:100px;
			color:white;
		}

		.bg_text4_6_2{
			top:525px;
			left:80px;
			font-size:30px;
			text-align:left;
			width:100px;
			color:white;
		}

		.bg_text4_6_3{
			top:175px;
			left:245px;
			font-size:20px;
			text-align:left;
			width:150px;
			color:white;
		}

		.bg_text4_6_4{
			top:175px;
			left:430px;
			font-size:20px;
			text-align:left;
			width:150px;
			color:white;
		}

		.bg_text5_0{
			top:10px;
			font-size:70px;
			font-weight:bold;
			color:white;
		}

		/* 見出し */
		.bg_text5_1_1{
			top:130px;
			left:490px;
			font-size:40px;
			color:white;
			width:400px;
		}
		.bg_text5_2_1{
			top:300px;
			left:420px;
			font-size:40px;
			color:white;
			width:400px;
		}
		.bg_text5_3_1{
			top:460px;
			left:480px;
			font-size:40px;
			color:white;
			width:500px;
		}

		/* 見出し下の説明文*/
		.bg_text5_1_2{
			top:215px;
			left:520px;
			font-size:20px;
			color:white;
			width:700px;
			text-align:left;
		}

		.bg_text5_2_2{
			top:360px;
			left:520px;
			font-size:20px;
			color:white;
			width:700px;
			text-align:left;
		}

		.bg_text5_3_2{
			top:550px;
			left:520px;
			font-size:20px;
			color:white;
			width:700px;
			text-align:left;
		}

		@media screen and (min-width: 1281px) {

			.demobtn{
			position:absolute;
			z-index:100;
			top:75%;
			left:50%;
			width:20%;
			height:9%;
			font-size:35px;
			border-radius:20px;
			}

			.bg_area{
			position:relative;
			top:0px;
			left:50%;
			width:1280px;
			margin-left:-640px;
			overflow:hidden;
			}

			body{
				width:100%;
				overflow-x:hidden;
			}

			.parent1 {
			position: relative;
			width: 100%;
			max-width: 1280px;
			position:relative;left:50%;margin-left:-640px;
			}
			.parent2 {
			position: relative;
			width: 100%;
			max-width: 1280px;
			position:relative;left:50%;margin-left:-640px;
			}
			.parent3 {
			position: relative;
			width: 100%;
			max-width: 1280px;
			position:relative;left:50%;margin-left:-640px;
			}
			.parent4 {
			position: relative;
			width: 100%;
			max-width: 1280px;
			position:relative;left:50%;margin-left:-640px;
			}
			.parent5 {
			position: relative;
			width: 100%;
			max-width: 1280px;
			position:relative;left:50%;margin-left:-640px;
			}

			.inner1{
			display: table-cell;
			vertical-align: middle;
			font-size:43px;
			}

			.inner2{
			font-size:32.25px;
			}
			.inner3{
			font-size:25px;
			}
			.inner4{
			font-size:37.5px!important;
			}
			.inner5{
			font-size:56.25px!important;
			font-weight:bold;
			}
		}

		

		.parent1:before {
		content: "";
		display: block;
		padding-top: 36.74%;
		}
		.parent2:before {
		content: "";
		display: block;
		padding-top: 55.95%;
		}
		.parent3:before {
		content: "";
		display: block;
		padding-top: 65.8%;
		}
		.parent4:before {
		content: "";
		display: block;
		padding-top: 55.93%;
		}
		.parent5:before {
		content: "";
		display: block;
		padding-top: 61.76%;
		}

		.child {
		position: absolute;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
		}

		.bg1{
			width:100%;
			height:36.74%;
		}
		.bg2{
			height:805px;
		}
		.bg3{
			height:841px;
		}
		.bg4{
			height:800px;
		}
		.bg5{
			height:791px;
		}

		body{
			
		}

		@media screen and (max-width: 1280px) {

		.demobtn{
		position:absolute;
		z-index:100;
		top:75%;
		left:50%;
		width:25%;
		height:12%;
		font-size:2.5vw;
		border-radius:20px;
		}

		.inner1{
		display: table-cell;
		vertical-align: middle;
		font-size:3vw;
		}

		.inner2{
		font-size:2.6vw;
		}
		.inner3{
		font-size:2.0vw;
		}
		.inner4{
		font-size:3.0vw!important;
		}
		.inner5{
		font-size:4.5vw!important;
		font-weight:bold;
		}
		
		.parent1 {
		position: relative;
		width: 100%;
		max-width: 1280px;
		}

		.parent2 {
		position: relative;
		width: 100%;
		max-width: 1280px;
		}

		.parent3 {
		position: relative;
		width: 100%;
		max-width: 1280px;
		}
		.parent4 {
		position: relative;
		width: 100%;
		max-width: 1280px;
		}
		.parent5 {
		position: relative;
		width: 100%;
		max-width: 1280px;
		}

			.bg_area{
			position:relative;
			top:0px;
			left:0px;
			width:100%;
			overflow:hidden;
			}

			body{
				width:100%;
				overflow-x:hidden;
			}

			.bg_image{
				width:100%;
				margin-left:-50%;
			}



	
		.bg_text2_1{
			top:60px;
			font-size:25px;
			color:#7E4D3D;
		}
		


			/* 見出し下の説明文*/
			.bg_text4_1{
				top:0px;
				left:0px;
				width:500px;
				font-size:20px;
				color:black;
				text-align:left;
			}

			.bg_text4_2_2{
				top:185px;
				left:0px;
				width:500px;
				font-size:20px;
				color:black;
				text-align:left;
			}

			.bg_text4_3_2{
				top:375px;
				left:0px;
				width:500px;
				font-size:20px;
				color:black;
				text-align:left;
			}

			.bg_text4_4_2{
				top:565px;
				left:0px;
				width:500px;
				font-size:20px;
				color:black;
				text-align:left;
			}

			.bg_text3_2{
				top:570px;
				left:50%;
				font-size:35px;
				color:black;
				font-weight:bold;
				width:800px;
				text-align:left;
			}

			/* 見出し */
			.bg_text4_2_1{
				top:110px;
				left:0px;
				font-size:35px;
				color:black;
				font-weight:bold;
				width:500px;
				text-align:left;
			}

			.bg_text4_3_1{
				top:310px;
				left:0px;
				font-size:35px;
				color:black;
				font-weight:bold;
				width:500px;
				text-align:left;
			}

			.bg_text4_4_1{
				top:490px;
				left:0px;
				font-size:35px;
				color:black;
				font-weight:bold;
				width:500px;
				text-align:left;
			}

			.bg_text4_block
			{
				position:absolute;
				top:0%;
				left:50%;
			}

			.bg_text4_block_inner
			{
				position:relative;
			}

			.bg2{
				height:640px;
			}

			.bg3{
				height:640px;
			}

			.bg4{
				height:650px;
			}

	.bg5{
			height:680px;
		}
			.bg_text4_6_1{
				top:255px;
				left:50px;
				font-size:30px;
				text-align:left;
				width:100px;
				color:white;
			}

			.bg_text4_6_2{
				top:395px;
				left:50px;
				font-size:30px;
				text-align:left;
				width:100px;
				color:white;
			}

			.bg_text4_6_3{
				top:135px;
				left:177.5px;
				font-size:20px;
				text-align:left;
				width:150px;
				color:white;
			}

			.bg_text4_6_4{
				top:135px;
				left:315px;
				font-size:20px;
				text-align:left;
				width:150px;
				color:white;
			}

			.bg_text3_1{
				top:100px;
				left:100px;
				font-size:30px;
				color:black;
				text-align:left;
				width:800px;
			}

			.bg_text2_1{
				top:0px;
				font-size:26px;
				width:100%;
				color:#7E4D3D;
			}

			.bg_text2_2{
				top:50px;
				width:100%;
				font-size:26px;
				color:#7E4D3D;
			}

			.bg_text1{
				top:120px;
				font-size:10%;
				width:100%;
				color:white;
			}
			
		.bg_text1_1{
			top:0px;
			font-size:33px;
			text-align: center;
			left: -130px;
			color:#7E4D3D;
		}

			.sp_style_demo_btn
			{
				position:relative!important;
				left:50%!important;
				top:440px!important;
			}

			.bg_text5_1_1{
				top:130px;
				left:480px;
				font-size:30px;
				color:white;
				width:400px;
				text-align:left;
			}
			.bg_text5_2_1{
				top:250px;
				left:480px;
				font-size:30px;
				color:white;
				width:400px;
				text-align:left;
			}
			.bg_text5_3_1{
				top:360px;
				left:480px;
				font-size:30px;
				color:white;
				width:400px;
				text-align:left;
			}

			/* 見出し下の説明文*/
			.bg_text5_1_2{
				top:180px;
				left:420px;
				font-size:17px;
				color:white;
				width:700px;
				text-align:left;
			}

			.bg_text5_2_2{
				top:290px;
				left:420px;
				font-size:17px;
				color:white;
				width:700px;
				text-align:left;
			}

			.bg_text5_3_2{
				top:410px;
				left:420px;
				font-size:17px;
				color:white;
				width:700px;
				text-align:left;
			}
			
		.bg_text5_0{
			top:10px;
			left:-100px;
			font-size:70px;
			font-weight:bold;
			color:white;
		}
			
					/* 見出し */
		.bg_text5_1_1{
			top:130px;
			left:420px;
			font-size:40px;
			color:white;
			width:400px;
		}
		.bg_text5_2_1{
			top:230px;
			left:420px;
			font-size:40px;
			color:white;
			width:400px;
		}
		.bg_text5_3_1{
			top:350px;
			left:420px;
			font-size:40px;
			color:white;
			width:500px;
		}


			.bg_text4_5{
				top:700px;
				font-size:30px;
				font-weight:bold;
				width:900px;
				margin-left:-450px;
			}

		}

		@media screen and (max-width: 500px) {
			.demo_mongon
			{
				margin-top:-30px;
			}
		}

		@media screen and (max-width: 1280px) and (min-width: 981px) {
			.bg_text2_1
			{
				top:50px;
				font-size:26px;
				width:100%;
				color:#7E4D3D;
			}

			.bg_text2_2
			{
				top:100px;
				font-size:26px;
				width:100%;
				color:#7E4D3D;
			}

			.bg2{
				height:60vw;
			}

			.bg3{
				height:66vw;
			}

			.bg4{
				height:82.5vw;
			}

			.sp_style_demo_btn
			{
				position:relative!important;
				left:53%!important;
				top:80%!important;
			}

			.bg_text4_5{
				top:70vw;
				font-size:30px;
				font-weight:bold;
				width:100vw;
				margin-left:-50vw;
			}

			.bg_text3_2{
				top:90%;
				left:50%;
				font-size:35px;
				color:black;
				font-weight:bold;
				width:800px;
				text-align:left;
			}

			.bg_text4_6_1{
				top:26vw;
				left:6.5vw;
				font-size:30px;
				text-align:left;
				width:100px;
				color:white;
			}

			.bg_text4_6_2{
				top:40.5vw;
				left:6.5vw;
				font-size:30px;
				text-align:left;
				width:100px;
				color:white;
			}

			.bg_text4_6_3{
				top:13vw;
				left:19.5vw;
				font-size:20px;
				text-align:left;
				width:150px;
				color:white;
			}

			.bg_text4_6_4{
				top:13vw;
				left:33.5vw;
				font-size:20px;
				text-align:left;
				width:150px;
				color:white;
			}

		}

		.text_block
		{
			width:100%;
			height:100%;
			
			position:absolute;
			left:0%;
			top:0%;
			
			text-align:center;

			font-size:300%;
			color:white;
		}

		.text_block_inner
		{
			position:relative;
			width:100%;
			height:100%;
		}

		.text_p1
		{
			position: absolute;
			top: 0;
			right: 0;
			bottom: 0;
			left: 0;
			margin: auto;
			width: 100%;
			text-align:center;
  			height: 100%;
			display: table;
		}

		.text_p2
		{
			position: absolute;
			top: 0;
			right: 0;
			bottom: 0;
			left: 0;
			margin: auto;
			width: 100%;
			text-align:center;
  			height: 100%;
		}
		
	</style>
	
</head>

<body>
<div class="main-wrap">
@include('layouts.header')

@include('layouts.inquery_form')

@include('layouts.inquery_responce')

@include('layouts.header2')




<div class="lp_main">

<div class="parent1">
<div class="child">
	<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/n1.jpg') }}">

			<div class="text_p1"><div class="inner1" style="color:white;">利便性・安全性の高い暗号通貨での入出金を可能にした<br/>クリプトユーザーが待ち望んだFX</div></div>

</div>
</div>

<div class="parent2" style="background-image: url('{{ asset('/img/btc_lp/n2_2.jpg') }}');background-size: cover;background-position: center;margin-top:50px;">
<div class="child">

			<div class="text_p2"><div class="inner2" style="color:#A14B35;">good enoughが提供するFXへはBTC・ETH・USDT・XRPでの入出金が可能です。<br/>MT4上ではUSDにて管理されます。資産管理は第三者機関によって厳重に管理されています。</div></div>
			<div class="text_p2"><a href="{{route('demo')}}" class="btn btn-primary mx-auto btn-slide mt-2 mx-0 demobtn"><span class="demo_mongon">デモ口座開設</span></a></div>

</div>
</div>
<!--
<div class="bg_area bg2">
	<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/n2_2.png') }}">
	<p class="bg_text bg_text2_1" >good enoughが提供するFXへはBTC・ETH・USDT・XRPでの入出金が可能です。</p>
	<p class="bg_text bg_text2_2" >MT4上ではUSDにて管理されます。資産管理は第三者機関によって厳重に管理されています。</p>
	<a href="{{route('demo')}}" class="btn btn-primary mx-auto btn-slide mt-2 mx-0 demobtn sp_style_demo_btn">デモ口座開設</a>
</div>
-->


<div class="parent3">
<div class="child">
	<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/n3.jpg') }}">

			<div class="text_p2"><div class="inner2" style="color:black;margin-top:10%;margin-left:-30%;">FXマーケットと暗号通貨両方のマーケットトレーダーに<br>
高い資産形成の可能性を提供しています。</div></div>

</div>
</div>
<!--
<div class="bg_area bg3">
	<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/n3.jpg') }}">
	<p class="bg_text bg_text3_1" >FXマーケットと暗号通貨両方のマーケットトレーダーに<br>
高い資産形成の可能性を提供しています。</p>
</div>
-->

<div class="parent4">
<div class="child">
	<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/n4.png') }}">

			<div class="text_p2"><div class="inner2" style="color:#A14B35;">入金された暗号通貨資産は即座に<br/>USDT・USDに変換し管理されています。</div></div>

</div>
</div>
<!--
<div class="bg_area bg4">
		<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/n4.png') }}">
	<p class="bg_text bg_text1_1" >入金された暗号通貨資産は即座に<br/>USDT・USDに変換し管理されています。</p>

	</div>
	</div>

</div>
-->


<div class="parent5" style="margin-top:50px;">
<div class="child">
	<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/5.jpg') }}">

			<div class="text_p2"><div class="inner3" style="color:white;text-align:left;margin-left:38%;">
			
			<span class="inner5">SECURITY</span>
			<div class="inner4" style="margin-top: 16px;">100% COLD WALLET</div>
			<span>管轄する全ての暗号通貨は直接COLDWALLETに送金されます。</span><br/>
			<span>いかなる秘密鍵もオンラインマシンに送金されることはありません。</span><br/>
			<div class="inner4" style="margin-top: 16px;">二段階認証</div>
			<span>全てのユーザーは、２要素認証によって追加のセキュリティサポートを</span>
			<span>受けることができます。</span><br/>
			<div class="inner4" style="margin-top: 16px;">自動またはAPI送信なし</div>
			<span>私たちは常に疑わしいユーザ又はハッキング等の動きがないか</span><br/>
			<span>システムを監視し、出金処理に関しては人間による確認作業を</span><br/>
			<span>行っています。</span>
			
			</div></div>

</div>
</div>
<!--
<div class="bg_area bg5">
	<img class="bg_image" alt="ロゴ" src="{{ asset('/img/btc_lp/5.jpg') }}">
	<p class="bg_text bg_text5_0" >SECURITY</p>

	<p class="bg_text bg_text5_1_1" >100% COLD WALLET</p>

	<p class="bg_text bg_text5_1_2" >管轄する全ての暗号通貨は直接COLDWALLETに送金されます。<br>
いかなる秘密鍵もオンラインマシンに送金されることはありません。</p>

	<p class="bg_text bg_text5_2_1" >二段階認証</p>

	<p class="bg_text bg_text5_2_2" >全てのユーザーは、２要素認証によって追加のセキュリティサポートを<br>受けることができます。</p>

	<p class="bg_text bg_text5_3_1" >自動またはAPI送信なし</p>

	<p class="bg_text bg_text5_3_2" >私たちは常に疑わしいユーザ又はハッキング等の動きがないか<br>システムを監視し、出金処理に関しては人間による確認作業を<br>行っています。</p>
</div>
-->
</div>

<style>

.btn-brawn
{
	background-color:#a14b35;
	color:white;
}

.tel-link a
{
	color:white;
}

</style>



@include('layouts.footer')




<script type="text/javascript" src="{{$currentPath}}/../assets/js/signature_pad.umd.js"></script>

<script type="text/javascript" src="{{$currentPath}}/../assets/js/app.min-v=0.01.25.js"></script>


</div>

</body>

</html>